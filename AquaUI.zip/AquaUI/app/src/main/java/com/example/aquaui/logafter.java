package com.example.aquaui;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.view.GravityCompat;
import androidx.drawerlayout.widget.DrawerLayout;

public class logafter extends AppCompatActivity {

    private DrawerLayout drawerLayout;
    private Button groupButton;
    private ImageButton ScanCode;
    private ImageButton tombolscan;
    private ImageButton yakalibzir;
    private ImageButton hehhh;
    private ImageButton lahlohhh;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_logafter);
        hehhh=findViewById(R.id.hehhh);
        hehhh.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent=new Intent(logafter.this, RoyalVaganza.class);
                startActivity(intent);
            }
        });

        lahlohhh=findViewById(R.id.lahlohhh);
        lahlohhh.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent=new Intent(logafter.this, RoyalVaganza.class);
                startActivity(intent);
            }
        });
        ScanCode=findViewById(R.id.ScanCode);
        ScanCode.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent=new Intent(logafter.this, scan1.class);
                startActivity(intent);
            }
        });

        tombolscan=findViewById(R.id.tombolscan);
        tombolscan.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent=new Intent(logafter.this, scan1.class);
                startActivity(intent);
            }
        });

        yakalibzir=findViewById(R.id.yakalibzir);
        yakalibzir.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent=new Intent(logafter.this, vaganzapoint.class);
                startActivity(intent);
            }
        });

        drawerLayout = findViewById(R.id.drawer_layout);
        groupButton = findViewById(R.id.garistiga);

        groupButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                drawerLayout.openDrawer(GravityCompat.END);
            }
        });


    }
}