package com.example.aquaui;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageButton;

import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Apply window insets to the main layout (if needed)
        // If you're not handling edge-to-edge display, you can remove this part

        // Set onClickListener for the ImageButton
        ImageButton mainButton = findViewById(R.id.imageButton);
        mainButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity.this, loginregisact.class);
                startActivity(intent);
            }
        });
    }
}
